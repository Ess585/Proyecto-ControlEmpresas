'use strict'
const express = require('express')
const {Router} = require('express')
const {createEnterprise, addSucursal, listEnterprises, updateEnterprise, deleteEnterprise, login, deleteSucursal, updateSucursal} = require("../controller/enterprise.controller")
const { validateJWT } = require('../middlewares/validateJWT')
const api = Router()

api.post('/create-enterprise', createEnterprise);
api.post('/add-sucursal/:id', validateJWT ,addSucursal);
api.get('/list-enterprises', listEnterprises);
api.put('/update-enterprise/:id',validateJWT, updateEnterprise);
api.put('/update-sucursal/:id',validateJWT,updateSucursal);
api.delete('/delete-enterprise/:id',validateJWT, deleteEnterprise);
api.delete('/delete-sucursal/:id',validateJWT, deleteSucursal);
api.post('/login',login)

module.exports = api;